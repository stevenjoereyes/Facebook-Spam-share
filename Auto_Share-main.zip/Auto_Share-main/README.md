# Auto_Share_Tool

# Assalamu Alaikum 

# Free Tools Enjoy

------------------------------

`@apt update`

`@apt upgrade`

`@apt install git`

`@pip install pyfiglet`

`@pip install toilet`

`@git clone https://github.com/D4rk-B0y/Auto_Share.git`

`@cd Auto_Share`

`@python share-pro.py`
